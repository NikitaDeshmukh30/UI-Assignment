import './App.css';
import { MainSection } from './Components/MainSection/MainSection';

function App() {
  return (
    <div className="App">
     <MainSection/>
    </div>
  );
}

export default App;
